import { useCallback } from 'react';
import useLocalStorage from './useLocalStorage';

export const useAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useLocalStorage('isAuthenticated', false);
  
  const login = useCallback(() => {
    // In a real app, you'd have async logic here to verify credentials.
    // For this simulation, we'll just set the user as authenticated.
    setIsAuthenticated(true);
  }, [setIsAuthenticated]);

  const logout = useCallback(() => {
    setIsAuthenticated(false);
  }, [setIsAuthenticated]);

  return { isAuthenticated, login, logout };
};

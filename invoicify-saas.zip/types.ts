
export interface BusinessInfo {
  name: string;
  address: string;
  email: string;
  phone: string;
  logoUrl?: string;
  currency: string;
  invoicePrefix: string;
}

export interface Product {
  id: string;
  name:string;
  description: string;
  price: number;
}

export interface Customer {
  id: string;
  name: string;
  email?: string;
  mobile: string;
  address: string;
}

export interface InvoiceItem {
  productId: string;
  productName: string;
  quantity: number;
  price: number;
}

export interface Invoice {
  id:string;
  invoiceNumber: string;
  customerId?: string;
  customerName: string;
  customerEmail?: string;
  customerMobile: string;
  customerAddress: string;
  issueDate: string;
  dueDate: string;
  items: InvoiceItem[];
  discount: number; // as amount
  tax: number; // as percentage
  status: 'DUE' | 'PAID';
}
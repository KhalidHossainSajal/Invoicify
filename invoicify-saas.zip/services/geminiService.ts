
import { GoogleGenAI } from "@google/genai";
import { type Invoice } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not set. Gemini features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generateSalesSummary = async (invoices: Invoice[]): Promise<string> => {
  if (!API_KEY) {
    return "Gemini API key is not configured. Please set the API_KEY environment variable.";
  }

  if (invoices.length === 0) {
    return "No sales data available for this period to generate a summary.";
  }

  const prompt = `
    You are a business analyst AI. Based on the following invoice data from the past week, provide a concise and insightful summary for the business owner.
    Highlight the total revenue, number of invoices paid, and top-selling products.
    The output should be a single paragraph of well-written, professional text. Do not use markdown.

    Invoice Data:
    ${invoices.map(inv => `
      - Invoice #${inv.invoiceNumber}:
        Customer: ${inv.customerName}
        Status: ${inv.status}
        Total: ${calculateInvoiceTotal(inv).grandTotal.toFixed(2)}
        Items: ${inv.items.map(item => `${item.quantity}x ${item.productName}`).join(', ')}
    `).join('')}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating sales summary:", error);
    return "An error occurred while generating the AI summary. Please check the console for details.";
  }
};


// Helper function to be consistent with invoice calculations
const calculateInvoiceTotal = (invoice: Invoice) => {
    const subtotal = invoice.items.reduce((acc, item) => acc + item.quantity * item.price, 0);
    const discountAmount = invoice.discount;
    const subtotalAfterDiscount = subtotal - discountAmount;
    const taxAmount = subtotalAfterDiscount * (invoice.tax / 100);
    const grandTotal = subtotalAfterDiscount + taxAmount;
    return { subtotal, discountAmount, taxAmount, grandTotal };
};

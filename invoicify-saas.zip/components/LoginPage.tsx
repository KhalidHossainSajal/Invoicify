import React from 'react';

interface LoginPageProps {
    onLogin: () => void;
    onNavigateToLanding: () => void;
    onNavigateToRegister: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin, onNavigateToLanding, onNavigateToRegister }) => {

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        // In a real app, you would validate credentials here.
        // For this demo, we'll just call the onLogin callback.
        onLogin();
    }

    return (
        <div className="min-h-screen bg-background dark:bg-gray-900 flex flex-col justify-center items-center p-4">
             <div className="absolute top-8 left-8">
                 <button onClick={onNavigateToLanding} className="text-primary font-semibold flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    Back to Home
                 </button>
            </div>
            <div className="max-w-md w-full bg-card dark:bg-gray-800 p-8 rounded-xl shadow-md">
                <div className="flex justify-center items-center mb-6">
                    <div className="bg-primary p-2 rounded-lg">
                        <PaperAirplaneIcon />
                    </div>
                    <h1 className="text-2xl font-bold ml-3 text-text-primary dark:text-gray-100">Invoicify</h1>
                </div>
                <h2 className="text-2xl font-bold text-center text-text-primary dark:text-gray-100">Sign in to your account</h2>
                <form className="mt-8 space-y-6" onSubmit={handleLogin}>
                    <div>
                        <label htmlFor="email" className="sr-only">Email address</label>
                        <input
                            id="email"
                            name="email"
                            type="email"
                            autoComplete="email"
                            required
                            className="w-full px-3 py-2 border border-border dark:border-gray-600 rounded-md placeholder-gray-500 text-text-primary bg-white dark:bg-gray-700 dark:text-white"
                            placeholder="Email address (e.g., user@example.com)"
                        />
                    </div>
                    <div>
                        <label htmlFor="password" className="sr-only">Password</label>
                        <input
                            id="password"
                            name="password"
                            type="password"
                            autoComplete="current-password"
                            required
                            className="w-full px-3 py-2 border border-border dark:border-gray-600 rounded-md placeholder-gray-500 text-text-primary bg-white dark:bg-gray-700 dark:text-white"
                            placeholder="Password"
                        />
                    </div>
                    <div>
                        <button
                            type="submit"
                            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                        >
                            Sign in
                        </button>
                    </div>
                </form>
                 <p className="mt-6 text-center text-sm text-text-secondary dark:text-gray-400">
                    Don't have an account?{' '}
                    <button onClick={onNavigateToRegister} className="font-medium text-primary hover:text-blue-500">
                        Sign Up
                    </button>
                </p>
            </div>
             <p className="mt-6 text-center text-sm text-text-secondary dark:text-gray-400">
                This is a demo. Any email/password will work.
            </p>
        </div>
    );
};

// Icon
const PaperAirplaneIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
    </svg>
);

export default LoginPage;
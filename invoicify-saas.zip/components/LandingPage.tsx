
import React from 'react';

interface LandingPageProps {
  onNavigateToLogin: () => void;
  onNavigateToRegister: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onNavigateToLogin, onNavigateToRegister }) => {
  return (
    <div className="bg-background dark:bg-gray-900 min-h-screen">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <div className="bg-primary p-2 rounded-lg">
              <PaperAirplaneIcon />
            </div>
            <h1 className="text-2xl font-bold ml-3 text-text-primary dark:text-gray-100">Invoicify</h1>
          </div>
          <nav>
            <button onClick={onNavigateToLogin} className="bg-primary text-white py-2 px-5 rounded-lg font-semibold hover:bg-blue-600 transition-colors">
              Login
            </button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <main className="container mx-auto px-6 py-16 text-center">
        <h2 className="text-4xl md:text-5xl font-bold text-text-primary dark:text-gray-100 leading-tight mb-4">
          Effortless Invoicing for Modern Businesses
        </h2>
        <p className="text-lg text-text-secondary dark:text-gray-400 max-w-2xl mx-auto mb-8">
          Manage your products, create beautiful invoices, track payments, and get AI-powered insights to grow your business faster.
        </p>
        <button onClick={onNavigateToRegister} className="bg-secondary text-white py-3 px-8 rounded-lg text-lg font-semibold hover:bg-green-600 transition-colors">
          Get Started for Free
        </button>
      </main>

      {/* Features Section */}
      <section className="bg-white dark:bg-gray-800 py-20">
        <div className="container mx-auto px-6">
          <h3 className="text-3xl font-bold text-center text-text-primary dark:text-gray-100 mb-12">Why Choose Invoicify?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            <div className="feature">
              <div className="bg-primary/10 text-primary rounded-full h-16 w-16 mx-auto flex items-center justify-center mb-4">
                <LightningBoltIcon />
              </div>
              <h4 className="text-xl font-semibold mb-2 dark:text-gray-200">Fast & Easy Invoicing</h4>
              <p className="text-text-secondary dark:text-gray-400">Create and send professional invoices in seconds with our intuitive editor.</p>
            </div>
            <div className="feature">
                <div className="bg-secondary/10 text-secondary rounded-full h-16 w-16 mx-auto flex items-center justify-center mb-4">
                    <SparklesIcon />
                </div>
              <h4 className="text-xl font-semibold mb-2 dark:text-gray-200">AI-Powered Insights</h4>
              <p className="text-text-secondary dark:text-gray-400">Get smart, actionable summaries of your weekly sales performance, powered by Gemini.</p>
            </div>
            <div className="feature">
                <div className="bg-primary/10 text-primary rounded-full h-16 w-16 mx-auto flex items-center justify-center mb-4">
                    <ChartPieIcon />
                </div>
              <h4 className="text-xl font-semibold mb-2 dark:text-gray-200">Powerful Reporting</h4>
              <p className="text-text-secondary dark:text-gray-400">Track your income, top products, and business growth with clear, visual reports.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-sidebar text-white py-8">
        <div className="container mx-auto px-6 text-center">
          <p>&copy; {new Date().getFullYear()} Invoicify. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

// Icons
const PaperAirplaneIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
    </svg>
);
const LightningBoltIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>;
const SparklesIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m11-1V5m2 2h-4m2 11h-4m0 2v-4M12 3v4m-2 2h4m2 11h-4m0 2v-4" /></svg>;
const ChartPieIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 3.055A9 9 0 0119.945 13H11V3.055z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.488 9A9.004 9.004 0 0113 20.488V11H3.512A9.004 9.004 0 0111 3.512v7.476z" /></svg>;

export default LandingPage;

import React, { useState } from 'react';
import Sidebar from './Sidebar';
import Dashboard from './Dashboard';
import InvoiceList from './InvoiceList';
import ProductList from './ProductList';
import Reports from './Reports';
import Settings from './Settings';
import InvoiceEditor from './InvoiceEditor';
import InvoiceView from './InvoiceView';
import { type Invoice, type Customer } from '../types';
import useLocalStorage from '../hooks/useLocalStorage';
import { generateId } from '../lib/utils';

type Page = 'DASHBOARD' | 'INVOICES' | 'PRODUCTS' | 'REPORTS' | 'SETTINGS' | 'INVOICE_EDITOR' | 'INVOICE_VIEW';

interface MainLayoutProps {
  onLogout: () => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

const MainLayout: React.FC<MainLayoutProps> = ({ onLogout, theme, toggleTheme }) => {
  const [invoices, setInvoices] = useLocalStorage<Invoice[]>('invoices', []);
  const [customers, setCustomers] = useLocalStorage<Customer[]>('customers', []);
  const [currentPage, setCurrentPage] = useState<Page>('DASHBOARD');
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [viewingInvoice, setViewingInvoice] = useState<Invoice | null>(null);
  const [autoPrintOnLoad, setAutoPrintOnLoad] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  const navigateTo = (page: Page) => {
    setEditingInvoice(null);
    setViewingInvoice(null);
    setAutoPrintOnLoad(false);
    setCurrentPage(page);
  };

  const handleEditInvoice = (invoice: Invoice) => {
    setEditingInvoice(invoice);
    setCurrentPage('INVOICE_EDITOR');
  };

  const handleNewInvoice = () => {
    setEditingInvoice(null);
    setCurrentPage('INVOICE_EDITOR');
  }

  const handleViewInvoice = (invoice: Invoice) => {
    setViewingInvoice(invoice);
    setAutoPrintOnLoad(false);
    setCurrentPage('INVOICE_VIEW');
  };

  const handlePrintInvoice = (invoice: Invoice) => {
    setViewingInvoice(invoice);
    setAutoPrintOnLoad(true);
    setCurrentPage('INVOICE_VIEW');
  };
  
  const handleSaveInvoice = (invoiceToSave: Omit<Invoice, 'id'> & { id?: string }, isNew: boolean) => {
    // New Customer Logic: If a customer with the given mobile doesn't exist, create one.
    const { customerMobile, customerName, customerAddress, customerEmail } = invoiceToSave;
    const existingCustomer = customers.find(c => c.mobile === customerMobile);
    let customerId = existingCustomer?.id;

    if (!existingCustomer && customerMobile && customerName) {
        const newCustomer: Customer = {
            id: generateId(),
            name: customerName,
            mobile: customerMobile,
            address: customerAddress || '',
            email: customerEmail || '',
        };
        setCustomers(prevCustomers => [...prevCustomers, newCustomer]);
        customerId = newCustomer.id;
    }
    
    const finalInvoice = { ...invoiceToSave, customerId };

    if (isNew) {
        const newInvoiceWithId = { ...finalInvoice, id: generateId() } as Invoice;
        setInvoices(prevInvoices => [...prevInvoices, newInvoiceWithId]);
        handlePrintInvoice(newInvoiceWithId);
    } else {
        const updatedInvoice = finalInvoice as Invoice;
        setInvoices(invoices.map(inv => (inv.id === updatedInvoice.id ? updatedInvoice : inv)));
        navigateTo('INVOICES');
    }
  };

  const renderContent = () => {
    switch (currentPage) {
      case 'DASHBOARD':
        return <Dashboard onNewInvoice={handleNewInvoice} invoices={invoices} />;
      case 'INVOICES':
        return <InvoiceList invoices={invoices} setInvoices={setInvoices} onEditInvoice={handleEditInvoice} onNewInvoice={handleNewInvoice} onViewInvoice={handleViewInvoice} onPrintInvoice={handlePrintInvoice} />;
      case 'PRODUCTS':
        return <ProductList />;
      case 'REPORTS':
        return <Reports invoices={invoices}/>;
      case 'SETTINGS':
        return <Settings />;
      case 'INVOICE_EDITOR':
        return <InvoiceEditor invoice={editingInvoice} onSave={handleSaveInvoice} customers={customers} />;
      case 'INVOICE_VIEW':
        return viewingInvoice ? <InvoiceView invoice={viewingInvoice} autoPrint={autoPrintOnLoad} onBack={() => navigateTo('INVOICES')} onEdit={handleEditInvoice} /> : <p>Invoice not found.</p>;
      default:
        return <Dashboard onNewInvoice={handleNewInvoice} invoices={invoices} />;
    }
  };

  return (
    <div className="flex h-screen bg-background dark:bg-gray-900 text-text-primary dark:text-gray-100">
      <Sidebar
        currentPage={currentPage}
        navigateTo={navigateTo}
        onLogout={onLogout}
        isCollapsed={isSidebarCollapsed}
        setIsCollapsed={setIsSidebarCollapsed}
        theme={theme}
        toggleTheme={toggleTheme}
      />
      <main 
        className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 transition-all duration-300"
        style={{ marginLeft: isSidebarCollapsed ? '5rem' : '16rem' }}
      >
        {renderContent()}
      </main>
    </div>
  );
};

export default MainLayout;


import React, { useState, useEffect } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { type Invoice, type InvoiceItem, type Product, type BusinessInfo, type Customer } from '../types';
import { formatCurrency } from '../lib/utils';

interface InvoiceEditorProps {
  invoice: Invoice | null;
  onSave: (invoice: Omit<Invoice, 'id'> & { id?: string }, isNew: boolean) => void;
  customers: Customer[];
}

const today = new Date().toISOString().split('T')[0];

const InvoiceEditor: React.FC<InvoiceEditorProps> = ({ invoice, onSave, customers }) => {
  const [products] = useLocalStorage<Product[]>('products', []);
  const [businessInfo] = useLocalStorage<BusinessInfo>('businessInfo', { name: '', address: '', email: '', phone: '', logoUrl: '', currency: 'USD', invoicePrefix: 'INV-'});

  const emptyInvoice: Omit<Invoice, 'id'> = {
    invoiceNumber: `${businessInfo.invoicePrefix || 'INV-'}${Math.floor(1000 + Math.random() * 9000)}`,
    customerName: '',
    customerEmail: '',
    customerMobile: '',
    customerAddress: '',
    issueDate: today,
    dueDate: today,
    items: [],
    discount: 0,
    tax: 0,
    status: 'DUE',
  };

  const [currentInvoice, setCurrentInvoice] = useState<Omit<Invoice, 'id'> & {id?: string}>(
    invoice ? { ...invoice } : { ...emptyInvoice }
  );

  useEffect(() => {
    setCurrentInvoice(invoice ? { ...invoice } : { ...emptyInvoice });
  }, [invoice]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setCurrentInvoice({ ...currentInvoice, [name]: value });
  };
  
  const handleCustomerMobileBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const mobile = e.target.value;
    if (mobile) {
        const foundCustomer = customers.find(c => c.mobile === mobile);
        if (foundCustomer) {
            setCurrentInvoice(prev => ({
                ...prev,
                customerId: foundCustomer.id,
                customerName: foundCustomer.name,
                customerEmail: foundCustomer.email,
                customerAddress: foundCustomer.address,
            }));
        }
    }
  };

  const handleItemChange = (index: number, field: keyof InvoiceItem, value: any) => {
    const newItems = [...currentInvoice.items];
    const item = newItems[index];
    
    if (field === 'productId') {
        const product = products.find(p => p.id === value);
        if (product) {
            item.productId = product.id;
            item.productName = product.name;
            item.price = product.price;
        }
    } else {
        (item[field] as any) = value;
    }

    setCurrentInvoice({ ...currentInvoice, items: newItems });
  };

  const addItem = () => {
    const firstProduct = products[0];
    if (!firstProduct) {
        alert("Please add a product first!");
        return;
    }
    setCurrentInvoice({
      ...currentInvoice,
      items: [
        ...currentInvoice.items,
        { productId: firstProduct.id, productName: firstProduct.name, quantity: 1, price: firstProduct.price },
      ],
    });
  };

  const removeItem = (index: number) => {
    const newItems = currentInvoice.items.filter((_, i) => i !== index);
    setCurrentInvoice({ ...currentInvoice, items: newItems });
  };

  const handleSave = () => {
    const isNewInvoice = !currentInvoice.id;
    onSave(currentInvoice, isNewInvoice);
  };

  const inputClasses = "w-full p-2 border border-border dark:border-gray-600 rounded text-text-primary bg-white dark:bg-gray-700 dark:text-white";
  const subtotal = currentInvoice.items.reduce((acc, item) => acc + item.quantity * item.price, 0);
  const discountAmount = Number(currentInvoice.discount);
  const subtotalAfterDiscount = subtotal - discountAmount;
  const taxAmount = subtotalAfterDiscount * (Number(currentInvoice.tax) / 100);
  const grandTotal = subtotalAfterDiscount + taxAmount;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">{invoice ? 'Edit Invoice' : 'Create Invoice'}</h1>
      
      <div className="bg-card dark:bg-gray-800 p-8 rounded-lg shadow-sm space-y-6">
        {/* Customer & Invoice Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h2 className="text-lg font-semibold mb-2">Bill To</h2>
            <input name="customerMobile" value={currentInvoice.customerMobile} onChange={handleChange} onBlur={handleCustomerMobileBlur} placeholder="Customer Mobile (auto-fills info)" className={`${inputClasses}`} />
            <input name="customerName" value={currentInvoice.customerName} onChange={handleChange} placeholder="Customer Name" className={`${inputClasses} mt-2`} />
            <input name="customerEmail" value={currentInvoice.customerEmail} onChange={handleChange} placeholder="Customer Email (Optional)" className={`${inputClasses} mt-2`} />
            <input name="customerAddress" value={currentInvoice.customerAddress} onChange={handleChange} placeholder="Customer Address" className={`${inputClasses} mt-2`} />
          </div>
          <div className="text-right">
             <h2 className="text-lg font-semibold mb-2 text-left md:text-right">Invoice Details</h2>
             <input name="invoiceNumber" value={currentInvoice.invoiceNumber} onChange={handleChange} className={inputClasses} />
             <div className="flex justify-end items-center mt-2">
                <label className="mr-2 text-text-secondary dark:text-gray-400">Issue Date:</label>
                <input type="date" name="issueDate" value={currentInvoice.issueDate} onChange={handleChange} className={inputClasses} />
             </div>
             <div className="flex justify-end items-center mt-2">
                <label className="mr-2 text-text-secondary dark:text-gray-400">Due Date:</label>
                <input type="date" name="dueDate" value={currentInvoice.dueDate} onChange={handleChange} className={inputClasses} />
             </div>
          </div>
        </div>

        {/* Items Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b dark:border-gray-700">
                <th className="text-left p-2 font-medium text-text-secondary dark:text-gray-400">Item</th>
                <th className="text-right p-2 font-medium text-text-secondary dark:text-gray-400">Quantity</th>
                <th className="text-right p-2 font-medium text-text-secondary dark:text-gray-400">Price</th>
                <th className="text-right p-2 font-medium text-text-secondary dark:text-gray-400">Total</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {currentInvoice.items.map((item, index) => (
                <tr key={index} className="border-b dark:border-gray-700">
                  <td className="p-2">
                    <select value={item.productId} onChange={(e) => handleItemChange(index, 'productId', e.target.value)} className={inputClasses}>
                        {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </td>
                  <td className="p-2"><input type="number" value={item.quantity} onChange={(e) => handleItemChange(index, 'quantity', Number(e.target.value))} className={`${inputClasses} w-20 text-right`} /></td>
                  <td className="p-2"><input type="number" value={item.price} onChange={(e) => handleItemChange(index, 'price', Number(e.target.value))} className={`${inputClasses} w-24 text-right`} /></td>
                  <td className="p-2 text-right">{formatCurrency(item.quantity * item.price, businessInfo.currency)}</td>
                  <td className="p-2 text-center"><button onClick={() => removeItem(index)} className="text-red-500 hover:text-red-700 text-2xl font-bold">&times;</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <button onClick={addItem} className="mt-4 bg-secondary text-white py-1 px-3 rounded text-sm">+ Add Item</button>
        </div>

        {/* Totals */}
        <div className="flex justify-end">
            <div className="w-full md:w-1/2 lg:w-1/3 space-y-2 text-text-secondary dark:text-gray-300">
                <div className="flex justify-between"><span className="font-medium">Subtotal:</span><span className="text-text-primary dark:text-white">{formatCurrency(subtotal, businessInfo.currency)}</span></div>
                <div className="flex justify-between items-center">
                    <span className="font-medium">Discount:</span>
                    <input type="number" name="discount" value={currentInvoice.discount} onChange={handleChange} className={`${inputClasses} w-24 text-right`} />
                </div>
                <div className="flex justify-between items-center">
                    <span className="font-medium">Tax (%):</span>
                    <input type="number" name="tax" value={currentInvoice.tax} onChange={handleChange} className={`${inputClasses} w-24 text-right`} />
                </div>
                <div className="flex justify-between border-t dark:border-gray-700 pt-2 mt-2 text-text-primary dark:text-white"><span className="font-bold text-lg">Grand Total:</span><span className="font-bold text-lg">{formatCurrency(grandTotal, businessInfo.currency)}</span></div>
            </div>
        </div>
      </div>

      <div className="flex justify-between items-center">
        <select name="status" value={currentInvoice.status} onChange={handleChange} className={`${inputClasses} w-auto`}>
          <option value="DUE">Due</option>
          <option value="PAID">Paid</option>
        </select>
        <button onClick={handleSave} className="bg-primary text-white py-2 px-6 rounded-lg font-semibold hover:bg-blue-600">Save Invoice</button>
      </div>
    </div>
  );
};

export default InvoiceEditor;

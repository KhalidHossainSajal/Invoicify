
import React, { useEffect } from 'react';
import { type Invoice, type BusinessInfo } from '../types';
import { formatCurrency, formatDate } from '../lib/utils';
import useLocalStorage from '../hooks/useLocalStorage';

interface InvoiceViewProps {
  invoice: Invoice;
  autoPrint?: boolean;
  onBack: () => void;
  onEdit: (invoice: Invoice) => void;
}

const InvoiceView: React.FC<InvoiceViewProps> = ({ invoice, autoPrint, onBack, onEdit }) => {
  const [businessInfo] = useLocalStorage<BusinessInfo>('businessInfo', { name: '', address: '', email: '', phone: '', logoUrl: '', currency: 'USD', invoicePrefix: 'INV-' });

  useEffect(() => {
    if (autoPrint) {
      setTimeout(() => window.print(), 500);
    }
  }, [autoPrint]);
  
  const subtotal = invoice.items.reduce((acc, item) => acc + item.quantity * item.price, 0);
  const discountAmount = Number(invoice.discount);
  const subtotalAfterDiscount = subtotal - discountAmount;
  const taxAmount = subtotalAfterDiscount * (Number(invoice.tax) / 100);
  const grandTotal = subtotalAfterDiscount + taxAmount;

  return (
    <>
      <div className="flex justify-between items-center mb-6 print:hidden">
        <div>
            <button onClick={onBack} className="text-primary font-semibold flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
                Back to Invoices
            </button>
        </div>
        <div className="flex items-center gap-2">
            <button onClick={() => onEdit(invoice)} className="bg-gray-200 dark:bg-gray-700 text-text-primary dark:text-gray-200 py-2 px-4 rounded-lg font-semibold hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors">Edit</button>
            <button onClick={() => window.print()} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-blue-600 transition-colors">Print / Save PDF</button>
        </div>
      </div>

      <div className="bg-card dark:bg-gray-800 p-8 md:p-12 rounded-lg shadow-lg border-t-4 border-primary print:shadow-none print:border-t-4" id="invoice-to-print">
        <header className="flex justify-between items-start pb-8 border-b dark:border-gray-700 print:border-gray-400">
            <div>
                 {businessInfo.logoUrl ? (
                    <img src={businessInfo.logoUrl} alt="Business Logo" className="h-16 w-auto max-w-xs object-contain" />
                ) : (
                    <div className="bg-primary h-16 w-16 flex items-center justify-center rounded-md">
                        <span className="text-white text-3xl font-bold">{businessInfo.name ? businessInfo.name.charAt(0) : 'B'}</span>
                    </div>
                )}
            </div>
            <div className="text-right">
                <h2 className="text-4xl font-bold uppercase text-gray-400 dark:text-gray-500 print:text-black">Invoice</h2>
                <p className="text-lg mt-2 text-text-secondary dark:text-gray-400 print:text-gray-600"># {invoice.invoiceNumber}</p>
                 <p className={`mt-4 text-2xl font-bold ${invoice.status === 'PAID' ? 'text-secondary' : 'text-red-500'} print:text-black`}>{invoice.status}</p>
            </div>
        </header>
        
        <section className="grid md:grid-cols-2 gap-8 my-8">
            <div>
                <h3 className="font-semibold text-text-secondary dark:text-gray-400 print:text-gray-600 mb-2">From:</h3>
                <p className="font-bold text-lg text-text-primary dark:text-white print:text-black">{businessInfo.name}</p>
                <p className="text-text-secondary dark:text-gray-400 print:text-gray-600">{businessInfo.address}</p>
                <p className="text-text-secondary dark:text-gray-400 print:text-gray-600">{businessInfo.email}</p>
                <p className="text-text-secondary dark:text-gray-400 print:text-gray-600">{businessInfo.phone}</p>
            </div>
            <div className="md:text-right">
                <h3 className="font-semibold text-text-secondary dark:text-gray-400 print:text-gray-600 mb-2">Bill To:</h3>
                <p className="font-bold text-lg text-text-primary dark:text-white print:text-black">{invoice.customerName}</p>
                <p className="text-text-secondary dark:text-gray-400 print:text-gray-600">{invoice.customerAddress}</p>
                <p className="text-text-secondary dark:text-gray-400 print:text-gray-600">{invoice.customerMobile}</p>
                {invoice.customerEmail && <p className="text-text-secondary dark:text-gray-400 print:text-gray-600">{invoice.customerEmail}</p>}
            </div>
        </section>

        <section className="grid md:grid-cols-2 gap-8 my-8">
             <div></div>
             <div className="md:text-right">
                <div className="grid grid-cols-2 gap-x-8 gap-y-2 text-right">
                    <span className="font-semibold text-text-secondary dark:text-gray-400 print:text-gray-600">Issue Date:</span>
                    <span className="text-text-primary dark:text-white print:text-black">{formatDate(invoice.issueDate)}</span>
                    <span className="font-semibold text-text-secondary dark:text-gray-400 print:text-gray-600">Due Date:</span>
                    <span className="text-text-primary dark:text-white print:text-black">{formatDate(invoice.dueDate)}</span>
                </div>
            </div>
        </section>


        <section>
          <table className="w-full text-left">
            <thead className="bg-gray-50 dark:bg-gray-700 print:bg-gray-200">
              <tr>
                <th className="p-3 font-semibold text-text-secondary dark:text-gray-300 print:text-black uppercase tracking-wider">Item</th>
                <th className="p-3 font-semibold text-text-secondary dark:text-gray-300 print:text-black uppercase tracking-wider text-right">Quantity</th>
                <th className="p-3 font-semibold text-text-secondary dark:text-gray-300 print:text-black uppercase tracking-wider text-right">Price</th>
                <th className="p-3 font-semibold text-text-secondary dark:text-gray-300 print:text-black uppercase tracking-wider text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {invoice.items.map((item, index) => (
                <tr key={index} className="border-b dark:border-gray-700 print:border-gray-400">
                  <td className="p-3 text-text-primary dark:text-white print:text-black font-medium">{item.productName}</td>
                  <td className="p-3 text-text-secondary dark:text-gray-300 print:text-black text-right">{item.quantity}</td>
                  <td className="p-3 text-text-secondary dark:text-gray-300 print:text-black text-right">{formatCurrency(item.price, businessInfo.currency)}</td>
                  <td className="p-3 text-text-primary dark:text-white print:text-black font-medium text-right">{formatCurrency(item.quantity * item.price, businessInfo.currency)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <section className="flex justify-end mt-8">
            <div className="w-full md:w-1/2 lg:w-2/5 space-y-2 text-text-secondary dark:text-gray-300 print:text-black">
                <div className="flex justify-between"><span className="font-medium">Subtotal:</span><span className="font-medium text-text-primary dark:text-white print:text-black">{formatCurrency(subtotal, businessInfo.currency)}</span></div>
                <div className="flex justify-between"><span className="font-medium">Discount:</span><span className="font-medium text-text-primary dark:text-white print:text-black">- {formatCurrency(discountAmount, businessInfo.currency)}</span></div>
                <div className="flex justify-between"><span className="font-medium">Tax ({invoice.tax}%):</span><span className="font-medium text-text-primary dark:text-white print:text-black">+ {formatCurrency(taxAmount, businessInfo.currency)}</span></div>
                <div className="border-t dark:border-gray-600 print:border-gray-400 my-2"></div>
                <div className="flex justify-between text-text-primary dark:text-white print:text-black"><span className="font-bold text-xl">Grand Total:</span><span className="font-bold text-xl">{formatCurrency(grandTotal, businessInfo.currency)}</span></div>
            </div>
        </section>

        <footer className="text-center mt-12 pt-6 border-t dark:border-gray-700 print:border-gray-400">
            <p className="text-text-secondary dark:text-gray-400 print:text-gray-600">Thank you for your business!</p>
            <p className="text-xs text-gray-400 dark:text-gray-500 print:text-gray-500 mt-2">Invoice generated with Invoicify</p>
        </footer>
      </div>
      <style>{`
        @media print {
            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            body * {
                visibility: hidden;
            }
            #invoice-to-print, #invoice-to-print * {
                visibility: visible;
            }
            #invoice-to-print {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                font-size: 12px;
                box-shadow: none !important;
                border-radius: 0;
            }
            .print\\:text-black { color: #000 !important; }
            .print\\:text-gray-600 { color: #4B5563 !important; }
            .print\\:text-gray-500 { color: #6B7280 !important; }
            .print\\:border-gray-400 { border-color: #9CA3AF !important; }
            .print\\:bg-gray-200 { background-color: #E5E7EB !important; }
        }
      `}</style>
    </>
  );
};

export default InvoiceView;

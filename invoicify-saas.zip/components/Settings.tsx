
import React, { useState } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { type BusinessInfo } from '../types';

const Settings: React.FC = () => {
  const [businessInfo, setBusinessInfo] = useLocalStorage<BusinessInfo>('businessInfo', {
    name: '',
    address: '',
    email: '',
    phone: '',
    logoUrl: '',
    currency: 'USD',
    invoicePrefix: 'INV-'
  });
  const [notification, setNotification] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBusinessInfo({ ...businessInfo, [e.target.name]: e.target.value });
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setBusinessInfo({ ...businessInfo, logoUrl: event.target?.result as string });
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setBusinessInfo(businessInfo);
    setNotification('Settings saved successfully!');
    setTimeout(() => setNotification(''), 3000);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Business Settings</h1>
      <div className="bg-card dark:bg-gray-800 p-8 rounded-lg shadow-sm">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex items-center space-x-6">
            <div className="shrink-0">
              <img className="h-20 w-20 object-cover rounded-full" src={businessInfo.logoUrl || `https://ui-avatars.com/api/?name=${businessInfo.name || 'B'}&background=3B82F6&color=fff&size=80`} alt="Business logo" />
            </div>
            <label className="block">
              <span className="sr-only">Choose profile photo</span>
              <input type="file" onChange={handleFileChange} className="block w-full text-sm text-slate-500 dark:text-gray-400
                file:mr-4 file:py-2 file:px-4
                file:rounded-full file:border-0
                file:text-sm file:font-semibold
                file:bg-blue-50 file:text-primary
                hover:file:bg-blue-100
                dark:file:bg-gray-700 dark:file:text-blue-300 dark:hover:file:bg-gray-600
              "/>
            </label>
          </div>
          <div>
            <label className="block text-sm font-medium text-text-secondary dark:text-gray-400">Business Name</label>
            <input type="text" name="name" value={businessInfo.name} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-border dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary text-text-primary bg-white dark:bg-gray-700 dark:text-white" />
          </div>
          <div>
            <label className="block text-sm font-medium text-text-secondary dark:text-gray-400">Address</label>
            <input type="text" name="address" value={businessInfo.address} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-border dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary text-text-primary bg-white dark:bg-gray-700 dark:text-white" />
          </div>
          <div>
            <label className="block text-sm font-medium text-text-secondary dark:text-gray-400">Email</label>
            <input type="email" name="email" value={businessInfo.email} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-border dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary text-text-primary bg-white dark:bg-gray-700 dark:text-white" />
          </div>
          <div>
            <label className="block text-sm font-medium text-text-secondary dark:text-gray-400">Phone</label>
            <input type="tel" name="phone" value={businessInfo.phone} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-border dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary text-text-primary bg-white dark:bg-gray-700 dark:text-white" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label className="block text-sm font-medium text-text-secondary dark:text-gray-400">Currency Symbol</label>
                <input type="text" name="currency" value={businessInfo.currency} onChange={handleChange} placeholder="e.g., USD, EUR" className="mt-1 block w-full px-3 py-2 border border-border dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary text-text-primary bg-white dark:bg-gray-700 dark:text-white" />
            </div>
            <div>
                <label className="block text-sm font-medium text-text-secondary dark:text-gray-400">Invoice Prefix</label>
                <input type="text" name="invoicePrefix" value={businessInfo.invoicePrefix} onChange={handleChange} placeholder="e.g., INV-" className="mt-1 block w-full px-3 py-2 border border-border dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary text-text-primary bg-white dark:bg-gray-700 dark:text-white" />
            </div>
          </div>
          <div className="flex justify-end">
            <button type="submit" className="bg-primary text-white py-2 px-6 rounded-lg font-semibold hover:bg-blue-600 transition-colors">
              Save Settings
            </button>
          </div>
        </form>
      </div>
      {notification && (
        <div className="mt-4 p-4 text-sm text-green-700 bg-green-100 rounded-lg dark:bg-green-900 dark:text-green-300" role="alert">
          <span className="font-medium">Success!</span> {notification}
        </div>
      )}
    </div>
  );
};

export default Settings;

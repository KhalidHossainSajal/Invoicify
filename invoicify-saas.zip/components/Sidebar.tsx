
import React from 'react';

// FIX: Add 'CUSTOMERS', 'INVOICE_VIEW' to Page type to match the type in MainLayout.
type Page = 'DASHBOARD' | 'INVOICES' | 'PRODUCTS' | 'REPORTS' | 'SETTINGS' | 'INVOICE_EDITOR' | 'INVOICE_VIEW';

interface SidebarProps {
  currentPage: Page;
  navigateTo: (page: Page) => void;
  onLogout: () => void;
  isCollapsed: boolean;
  setIsCollapsed: (isCollapsed: boolean) => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

const NavItem: React.FC<{
  icon: React.ReactElement;
  label: string;
  isActive: boolean;
  onClick: () => void;
  isCollapsed: boolean;
}> = ({ icon, label, isActive, onClick, isCollapsed }) => (
  <li
    className={`flex items-center p-3 my-1 rounded-lg cursor-pointer transition-colors duration-200 ${
      isActive
        ? 'bg-sidebar-active text-white'
        : 'text-gray-300 hover:bg-sidebar-hover hover:text-white'
    } ${isCollapsed ? 'justify-center' : ''}`}
    onClick={onClick}
    title={isCollapsed ? label : ''}
    aria-label={label}
  >
    {icon}
    {!isCollapsed && <span className="ml-3 font-medium whitespace-nowrap">{label}</span>}
  </li>
);

const Sidebar: React.FC<SidebarProps> = ({ currentPage, navigateTo, onLogout, isCollapsed, setIsCollapsed, theme, toggleTheme }) => {
  const navItems = [
    { id: 'DASHBOARD', label: 'Dashboard', icon: <HomeIcon /> },
    { id: 'INVOICES', label: 'Invoices', icon: <DocumentIcon /> },
    { id: 'PRODUCTS', label: 'Products', icon: <CubeIcon /> },
    { id: 'REPORTS', label: 'Reports', icon: <ChartBarIcon /> },
    { id: 'SETTINGS', label: 'Settings', icon: <CogIcon /> },
  ];

  return (
    <aside className={`bg-sidebar text-white flex flex-col p-4 transition-all duration-300 relative ${isCollapsed ? 'w-20' : 'w-64'}`}>
      <div className={`flex items-center mb-8 ${isCollapsed ? 'justify-center' : 'justify-between'}`}>
        <div className={`flex items-center overflow-hidden transition-all duration-300 ${isCollapsed ? 'w-0' : 'w-full'}`}>
            <div className="bg-primary p-2 rounded-lg">
                <PaperAirplaneIcon />
            </div>
            <h1 className="text-2xl font-bold ml-3 whitespace-nowrap">Invoicify</h1>
        </div>
        <button 
            onClick={() => setIsCollapsed(!isCollapsed)} 
            className="absolute top-5 bg-sidebar-hover p-1.5 rounded-full z-10 focus:outline-none focus:ring-2 focus:ring-white transition-all duration-300"
            style={{ right: '-12px' }}
            aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          <ChevronLeftIcon isCollapsed={isCollapsed} />
        </button>
      </div>
      <nav>
        <ul>
          {navItems.map((item) => (
            <NavItem
              key={item.id}
              icon={item.icon}
              label={item.label}
              // FIX: Update isActive logic to highlight 'Invoices' when viewing or editing an invoice.
              isActive={currentPage === item.id || ((currentPage === 'INVOICE_EDITOR' || currentPage === 'INVOICE_VIEW') && item.id === 'INVOICES')}
              onClick={() => navigateTo(item.id as Page)}
              isCollapsed={isCollapsed}
            />
          ))}
        </ul>
      </nav>
      <div className="mt-auto">
          <div className={`bg-sidebar-hover rounded-lg text-center transition-all duration-300 overflow-hidden ${isCollapsed ? 'h-0 opacity-0 p-0' : 'h-auto opacity-100 p-4'}`}>
              <p className="text-sm text-gray-300">Upgrade to Pro</p>
              <p className="text-xs text-gray-400 mt-1">Unlock advanced features.</p>
              <button className="w-full mt-3 bg-primary text-white py-2 px-4 rounded-lg text-sm font-semibold hover:bg-blue-500 transition-colors">
                  Upgrade
              </button>
          </div>
          <button 
            onClick={toggleTheme}
            className={`w-full flex items-center p-3 mt-4 rounded-lg cursor-pointer transition-colors duration-200 text-gray-300 hover:bg-sidebar-hover hover:text-white ${isCollapsed ? 'justify-center' : ''}`}
            title="Toggle Theme"
            aria-label="Toggle Theme"
          >
              {theme === 'light' ? <MoonIcon /> : <SunIcon />}
              {!isCollapsed && <span className="ml-3 font-medium whitespace-nowrap">Theme</span>}
          </button>
          <button 
            onClick={onLogout}
            className={`w-full flex items-center p-3 mt-1 rounded-lg cursor-pointer transition-colors duration-200 text-gray-300 hover:bg-sidebar-hover hover:text-white ${isCollapsed ? 'justify-center' : ''}`}
            title="Logout"
            aria-label="Logout"
          >
              <LogoutIcon />
              {!isCollapsed && <span className="ml-3 font-medium whitespace-nowrap">Logout</span>}
          </button>
      </div>
    </aside>
  );
};

// SVG Icons
const HomeIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>);
const DocumentIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>);
const CubeIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-14L4 7m0 10l8 4m0-14v10" /></svg>);
const ChartBarIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>);
const CogIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>);
const PaperAirplaneIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>);
const LogoutIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>);
const MoonIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>);
const SunIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>);
const ChevronLeftIcon = ({ isCollapsed }: { isCollapsed: boolean }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 text-white transition-transform duration-300 ${isCollapsed ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" /></svg>
);

export default Sidebar;

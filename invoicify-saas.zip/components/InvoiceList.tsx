import React, { useState, useEffect, useRef } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { type Invoice, type BusinessInfo } from '../types';
import { formatCurrency, formatDate } from '../lib/utils';
// FIX: Changed to named import to fix module augmentation issue.
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

// FIX: Augment jsPDF type to include autoTable method from jspdf-autotable plugin.
declare module 'jspdf' {
    interface jsPDF {
        autoTable: (options: any) => jsPDF;
    }
}

interface InvoiceListProps {
  invoices: Invoice[];
  setInvoices: React.Dispatch<React.SetStateAction<Invoice[]>>;
  onEditInvoice: (invoice: Invoice) => void;
  onNewInvoice: () => void;
  onViewInvoice: (invoice: Invoice) => void;
  onPrintInvoice: (invoice: Invoice) => void;
}

const InvoiceList: React.FC<InvoiceListProps> = ({ invoices, setInvoices, onEditInvoice, onNewInvoice, onViewInvoice, onPrintInvoice }) => {
  // FIX: Provide a complete default object for BusinessInfo to satisfy the type.
  const [businessInfo] = useLocalStorage<BusinessInfo>('businessInfo', {
    name: '',
    address: '',
    email: '',
    phone: '',
    logoUrl: '',
    currency: 'USD',
    invoicePrefix: 'INV-'
  });
  const [filter, setFilter] = useState<'ALL' | 'PAID' | 'DUE'>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [openDropdownId, setOpenDropdownId] = useState<string | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setOpenDropdownId(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredInvoices = invoices
    .filter(inv => filter === 'ALL' || inv.status === filter)
    .filter(inv => 
        inv.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        inv.customerName.toLowerCase().includes(searchTerm.toLowerCase())
    );

  const toggleStatus = (id: string) => {
    setInvoices(
      invoices.map(inv =>
        inv.id === id ? { ...inv, status: inv.status === 'DUE' ? 'PAID' : 'DUE' } : inv
      )
    );
  };

  const deleteInvoice = (id: string) => {
    if (window.confirm('Are you sure you want to delete this invoice?')) {
        setInvoices(invoices.filter(inv => inv.id !== id));
    }
  }

  const downloadPdf = (invoice: Invoice) => {
    const doc = new jsPDF();
    const businessInfo = JSON.parse(localStorage.getItem('businessInfo') || '{}');
    
    // Customer Copy
    doc.setFontSize(20);
    doc.text(businessInfo.name || 'Your Company', 14, 22);
    doc.setFontSize(12);
    doc.text('Customer Copy', 180, 22);

    doc.setFontSize(10);
    doc.text(businessInfo.address || '', 14, 30);
    doc.text(businessInfo.email || '', 14, 35);
    doc.text(businessInfo.phone || '', 14, 40);

    doc.autoTable({
        startY: 50,
        head: [['Item', 'Quantity', 'Price', 'Total']],
        body: invoice.items.map(item => [item.productName, item.quantity, formatCurrency(item.price, businessInfo.currency), formatCurrency(item.quantity * item.price, businessInfo.currency)]),
    });
    
    doc.line(10, 148.5, 200, 148.5); 

    doc.setFontSize(20);
    doc.text(businessInfo.name || 'Your Company', 14, 162);
    doc.setFontSize(12);
    doc.text('Business Copy', 180, 162);

    doc.setFontSize(10);
    doc.text(businessInfo.address || '', 14, 170);
    doc.text(businessInfo.email || '', 14, 175);
    doc.text(businessInfo.phone || '', 14, 180);

    doc.autoTable({
        startY: 190,
        head: [['Item', 'Quantity', 'Price', 'Total']],
        body: invoice.items.map(item => [item.productName, item.quantity, formatCurrency(item.price, businessInfo.currency), formatCurrency(item.quantity * item.price, businessInfo.currency)]),
    });


    doc.save(`invoice-${invoice.invoiceNumber}.pdf`);
  }
  
  const shareInvoice = async (invoice: Invoice) => {
    const total = invoice.items.reduce((sum, i) => sum + i.price * i.quantity, 0);
    const shareData = {
        title: `Invoice ${invoice.invoiceNumber}`,
        text: `Invoice for ${invoice.customerName} - ${formatCurrency(total, businessInfo.currency)} due on ${formatDate(invoice.dueDate)}.`,
        url: window.location.href,
    };
    try {
        if (navigator.share) {
            await navigator.share(shareData);
        } else {
            alert('Web Share API not supported in your browser.');
        }
    } catch (err) {
        console.error('Error sharing:', err);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center gap-4 flex-wrap">
        <h1 className="text-3xl font-bold">Invoices</h1>
        <div className="flex-grow sm:flex-grow-0">
          <input 
            type="text" 
            placeholder="Search by Invoice # or Customer..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full sm:w-64 px-3 py-2 border border-border dark:border-gray-600 rounded-md text-text-primary bg-white dark:bg-gray-700 dark:text-white"
          />
        </div>
        <button onClick={onNewInvoice} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-blue-600 transition-colors flex items-center">
            <PlusIcon className="h-5 w-5 mr-2" />
            New Invoice
        </button>
      </div>
      
      <div className="flex space-x-2">
        {(['ALL', 'PAID', 'DUE'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${filter === f ? 'bg-primary text-white' : 'bg-card dark:bg-gray-700 text-text-secondary dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600'}`}
          >
            {f.charAt(0) + f.slice(1).toLowerCase()}
          </button>
        ))}
      </div>

      <div className="bg-card dark:bg-gray-800 shadow-sm rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-300">
              <tr>
                <th scope="col" className="px-6 py-3">Invoice #</th>
                <th scope="col" className="px-6 py-3">Customer</th>
                <th scope="col" className="px-6 py-3">Date</th>
                <th scope="col" className="px-6 py-3">Amount</th>
                <th scope="col" className="px-6 py-3">Status</th>
                <th scope="col" className="px-6 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredInvoices.map((invoice) => (
                <tr key={invoice.id} className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                  <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">{invoice.invoiceNumber}</td>
                  <td className="px-6 py-4">{invoice.customerName}</td>
                  <td className="px-6 py-4">{formatDate(invoice.issueDate)}</td>
                  <td className="px-6 py-4">{formatCurrency(invoice.items.reduce((sum, i) => sum + i.price * i.quantity, 0), businessInfo.currency)}</td>
                  <td className="px-6 py-4">
                    <span
                      onClick={() => toggleStatus(invoice.id)}
                      className={`cursor-pointer inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        invoice.status === 'PAID'
                          ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                          : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
                      }`}
                    >
                      {invoice.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <div className="relative inline-block text-left" ref={dropdownRef}>
                        <button onClick={() => setOpenDropdownId(openDropdownId === invoice.id ? null : invoice.id)} className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
                            <DotsVerticalIcon />
                        </button>
                        {openDropdownId === invoice.id && (
                            <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white dark:bg-gray-800 ring-1 ring-black ring-opacity-5 focus:outline-none z-10">
                                <div className="py-1" role="menu" aria-orientation="vertical">
                                    <a href="#" onClick={(e) => { e.preventDefault(); onViewInvoice(invoice); setOpenDropdownId(null); }} className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700" role="menuitem"><EyeIcon/>View</a>
                                    <a href="#" onClick={(e) => { e.preventDefault(); onPrintInvoice(invoice); setOpenDropdownId(null); }} className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700" role="menuitem"><PrinterIcon/>Print</a>
                                    <a href="#" onClick={(e) => { e.preventDefault(); downloadPdf(invoice); setOpenDropdownId(null); }} className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700" role="menuitem"><DownloadIcon/>Download PDF</a>
                                    <a href="#" onClick={(e) => { e.preventDefault(); shareInvoice(invoice); setOpenDropdownId(null); }} className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700" role="menuitem"><ShareIcon/>Share</a>
                                    <div className="border-t border-gray-200 dark:border-gray-700 my-1"></div>
                                    <a href="#" onClick={(e) => { e.preventDefault(); onEditInvoice(invoice); setOpenDropdownId(null); }} className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700" role="menuitem"><PencilIcon/>Edit</a>
                                    <a href="#" onClick={(e) => { e.preventDefault(); deleteInvoice(invoice.id); setOpenDropdownId(null); }} className="flex items-center gap-3 px-4 py-2 text-sm text-red-600 hover:bg-gray-100 dark:hover:bg-gray-700" role="menuitem"><TrashIcon/>Delete</a>
                                </div>
                            </div>
                        )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// Icons
// FIX: Update PlusIcon to accept props, allowing className to be passed.
const PlusIcon = (props: React.SVGProps<SVGSVGElement>) => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}><path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" /></svg>;
const PencilIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" /></svg>;
const DownloadIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" /></svg>;
const TrashIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" /></svg>;
const DotsVerticalIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z" /></svg>;
const EyeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z" /><path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.022 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" /></svg>;
const PrinterIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5 4v3H4a2 2 0 00-2 2v6a2 2 0 002 2h12a2 2 0 002-2V9a2 2 0 00-2-2h-1V4a2 2 0 00-2-2H7a2 2 0 00-2 2zm8 0H7v3h6V4zm0 8H7v4h6v-4z" clipRule="evenodd" /></svg>;
const ShareIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z" /></svg>;

export default InvoiceList;
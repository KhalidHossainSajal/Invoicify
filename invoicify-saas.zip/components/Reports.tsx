import React, { useState, useMemo } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { type Invoice, type BusinessInfo } from '../types';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { formatCurrency, formatDate, calculateInvoiceGrandTotal } from '../lib/utils';
// FIX: Changed to named import to fix module augmentation issue.
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

// Augment jsPDF type to include autoTable method from jspdf-autotable plugin.
declare module 'jspdf' {
    interface jsPDF {
        autoTable: (options: any) => jsPDF;
    }
}

interface ReportsProps {
    invoices: Invoice[];
}

const StatCard: React.FC<{ title: string; value: string; }> = ({ title, value }) => (
  <div className="bg-card dark:bg-gray-700 p-4 rounded-lg shadow-sm">
      <p className="text-sm text-text-secondary dark:text-gray-400 font-medium">{title}</p>
      <p className="text-2xl font-bold text-text-primary dark:text-gray-100">{value}</p>
  </div>
);

const Reports: React.FC<ReportsProps> = ({ invoices }) => {
  const [businessInfo] = useLocalStorage<BusinessInfo>('businessInfo', {
    name: '', address: '', email: '', phone: '', logoUrl: '', currency: 'USD', invoicePrefix: 'INV-'
  });
  
  const todayISO = new Date().toISOString().split('T')[0];
  const [dateRange, setDateRange] = useState({ from: '', to: '' });
  const [selectedCustomer, setSelectedCustomer] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PAID' | 'DUE'>('ALL');

  const customers = useMemo(() => ['ALL', ...new Set(invoices.map(inv => inv.customerName))], [invoices]);

  const setDatePreset = (period: 'today' | 'week' | 'month' | 'year') => {
    const today = new Date();
    let fromDate = new Date();
    const toDate = new Date();

    if (period === 'today') {
        fromDate = today;
    } else if (period === 'week') {
        fromDate.setDate(today.getDate() - today.getDay());
    } else if (period === 'month') {
        fromDate = new Date(today.getFullYear(), today.getMonth(), 1);
    } else if (period === 'year') {
        fromDate = new Date(today.getFullYear(), 0, 1);
    }
    
    setDateRange({
        from: fromDate.toISOString().split('T')[0],
        to: toDate.toISOString().split('T')[0]
    });
  };

  const filteredInvoices = useMemo(() => {
    return invoices.filter(invoice => {
        const issueDate = new Date(invoice.issueDate);
        
        const fromDate = dateRange.from ? new Date(dateRange.from) : null;
        if(fromDate) fromDate.setHours(0,0,0,0);

        const toDate = dateRange.to ? new Date(dateRange.to) : null;
        if(toDate) toDate.setHours(23,59,59,999);
        
        if (fromDate && issueDate < fromDate) return false;
        if (toDate && issueDate > toDate) return false;
        
        if (selectedCustomer !== 'ALL' && invoice.customerName !== selectedCustomer) return false;
        if (statusFilter !== 'ALL' && invoice.status !== statusFilter) return false;
        
        return true;
    });
  }, [invoices, dateRange, selectedCustomer, statusFilter]);

  const salesData = useMemo(() => {
    const data: { [key: string]: { sales: number } } = {};
    filteredInvoices.forEach(invoice => {
        if(invoice.status !== 'PAID') return;
        const date = new Date(invoice.issueDate);
        const key = date.toISOString().split('T')[0]; // Group by day
        
        const total = calculateInvoiceGrandTotal(invoice);
        if (!data[key]) data[key] = { sales: 0 };
        data[key].sales += total;
    });
    return Object.keys(data).sort().map(key => ({ name: key, sales: data[key].sales }));
  }, [filteredInvoices]);
  
  const productSales = useMemo(() => {
      const data: {[key: string]: number} = {};
      filteredInvoices.forEach(invoice => {
          invoice.items.forEach(item => {
              data[item.productName] = (data[item.productName] || 0) + (item.quantity * item.price);
          })
      });
      return Object.entries(data).map(([name, sales]) => ({name, sales})).sort((a,b) => b.sales - a.sales).slice(0, 5);
  }, [filteredInvoices]);

  const summaryStats = useMemo(() => {
    const totalSales = filteredInvoices.reduce((sum, inv) => sum + calculateInvoiceGrandTotal(inv), 0);
    const amountPaid = filteredInvoices.filter(i => i.status === 'PAID').reduce((sum, inv) => sum + calculateInvoiceGrandTotal(inv), 0);
    const amountDue = totalSales - amountPaid;
    return { totalSales, amountPaid, amountDue, invoiceCount: filteredInvoices.length };
  }, [filteredInvoices]);

  const handleDownloadPdf = () => {
    const doc = new jsPDF();
    
    // Header
    doc.setFontSize(20);
    doc.text(businessInfo.name || 'Your Company', 14, 22);
    doc.setFontSize(12);
    doc.text('Sales Report', 14, 30);
    doc.setFontSize(10);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 200, 22, { align: 'right' });

    // Filter Summary
    doc.setFontSize(10);
    doc.text(`Period: ${dateRange.from ? formatDate(dateRange.from) : 'Start'} to ${dateRange.to ? formatDate(dateRange.to) : 'End'}`, 14, 40);
    doc.text(`Customer: ${selectedCustomer}`, 14, 45);
    doc.text(`Status: ${statusFilter}`, 14, 50);

    // Metrics Summary
    doc.text(`Total Invoices: ${summaryStats.invoiceCount}`, 200, 40, { align: 'right' });
    doc.text(`Total Sales: ${formatCurrency(summaryStats.totalSales, businessInfo.currency)}`, 200, 45, { align: 'right' });
    doc.text(`Amount Paid: ${formatCurrency(summaryStats.amountPaid, businessInfo.currency)}`, 200, 50, { align: 'right' });
    doc.text(`Amount Due: ${formatCurrency(summaryStats.amountDue, businessInfo.currency)}`, 200, 55, { align: 'right' });

    // Table
    const tableColumn = ["#", "Customer", "Issue Date", "Status", "Amount"];
    const tableRows = filteredInvoices.map(inv => [
        inv.invoiceNumber,
        inv.customerName,
        formatDate(inv.issueDate),
        inv.status,
        formatCurrency(calculateInvoiceGrandTotal(inv), businessInfo.currency)
    ]);

    doc.autoTable({
        head: [tableColumn],
        body: tableRows,
        startY: 65,
        headStyles: { fillColor: [59, 130, 246] }, // primary color
    });

    doc.save(`Invoicify_Report_${todayISO}.pdf`);
  };

  const inputClass = "w-full p-2 border border-border dark:border-gray-600 rounded text-text-primary bg-white dark:bg-gray-700 dark:text-white";
  const btnClass = "px-3 py-1.5 rounded-md text-sm font-medium transition-colors";
  const activeBtnClass = "bg-primary text-white";
  const inactiveBtnClass = "bg-gray-200 dark:bg-gray-700 text-text-secondary dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600";
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Reports</h1>
        <button onClick={handleDownloadPdf} className="bg-secondary text-white py-2 px-4 rounded-lg font-semibold hover:bg-green-600 transition-colors flex items-center">
            <DownloadIcon className="h-5 w-5 mr-2" />
            Download PDF
        </button>
      </div>

      {/* Filters */}
      <div className="bg-card dark:bg-gray-800 p-4 rounded-lg shadow-sm space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
                <label className="text-sm font-medium">From Date</label>
                <input type="date" value={dateRange.from} onChange={e => setDateRange({...dateRange, from: e.target.value})} className={inputClass} />
            </div>
            <div>
                <label className="text-sm font-medium">To Date</label>
                <input type="date" value={dateRange.to} onChange={e => setDateRange({...dateRange, to: e.target.value})} className={inputClass} />
            </div>
            <div>
                <label className="text-sm font-medium">Customer</label>
                <select value={selectedCustomer} onChange={e => setSelectedCustomer(e.target.value)} className={inputClass}>
                    {customers.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
            </div>
            <div>
                <label className="text-sm font-medium">Status</label>
                <div className="flex space-x-2 mt-1">
                    {(['ALL', 'PAID', 'DUE'] as const).map(s => (
                        <button key={s} onClick={() => setStatusFilter(s)} className={`${btnClass} ${statusFilter === s ? activeBtnClass : inactiveBtnClass}`}>
                            {s}
                        </button>
                    ))}
                </div>
            </div>
        </div>
        <div className="flex items-center space-x-2 pt-2 border-t dark:border-gray-700">
            <span className="text-sm font-medium">Presets:</span>
            <button onClick={() => setDatePreset('today')} className={`${btnClass} ${inactiveBtnClass}`}>Today</button>
            <button onClick={() => setDatePreset('week')} className={`${btnClass} ${inactiveBtnClass}`}>This Week</button>
            <button onClick={() => setDatePreset('month')} className={`${btnClass} ${inactiveBtnClass}`}>This Month</button>
            <button onClick={() => setDatePreset('year')} className={`${btnClass} ${inactiveBtnClass}`}>This Year</button>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Sales" value={formatCurrency(summaryStats.totalSales, businessInfo.currency)} />
        <StatCard title="Amount Paid" value={formatCurrency(summaryStats.amountPaid, businessInfo.currency)} />
        <StatCard title="Amount Due" value={formatCurrency(summaryStats.amountDue, businessInfo.currency)} />
        <StatCard title="Invoices Issued" value={String(summaryStats.invoiceCount)} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card dark:bg-gray-800 p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold mb-4">Sales Over Time</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.3} />
                <XAxis dataKey="name" tick={{ fill: 'currentColor', fontSize: 12 }} />
                <YAxis tickFormatter={(tick) => formatCurrency(tick as number, businessInfo.currency)} tick={{ fill: 'currentColor', fontSize: 12 }}/>
                <Tooltip contentStyle={{ backgroundColor: 'rgba(31, 41, 55, 0.8)', border: 'none' }} labelStyle={{ color: '#f3f4f6' }} formatter={(value) => formatCurrency(value as number, businessInfo.currency)} />
                <Legend wrapperStyle={{ color: 'currentColor' }}/>
                <Line type="monotone" dataKey="sales" stroke="#3B82F6" strokeWidth={2} activeDot={{ r: 8 }} />
              </LineChart>
            </ResponsiveContainer>
        </div>
        <div className="bg-card dark:bg-gray-800 p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold mb-4">Top Selling Products</h2>
            <ResponsiveContainer width="100%" height={300}>
                <BarChart data={productSales} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.3} />
                    <XAxis type="number" tickFormatter={(tick) => formatCurrency(tick as number, businessInfo.currency)} tick={{ fill: 'currentColor', fontSize: 12 }}/>
                    <YAxis type="category" dataKey="name" width={150} tick={{ fill: 'currentColor', fontSize: 12 }}/>
                    <Tooltip contentStyle={{ backgroundColor: 'rgba(31, 41, 55, 0.8)', border: 'none' }} labelStyle={{ color: '#f3f4f6' }} formatter={(value) => formatCurrency(value as number, businessInfo.currency)} />
                    <Bar dataKey="sales" fill="#10B981" />
                </BarChart>
            </ResponsiveContainer>
        </div>
      </div>
      
      {/* Detailed Invoice List */}
      <div className="bg-card dark:bg-gray-800 shadow-sm rounded-lg overflow-hidden">
        <h2 className="text-xl font-semibold p-4">Filtered Invoices ({filteredInvoices.length})</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-300">
              <tr>
                <th scope="col" className="px-6 py-3">Invoice #</th>
                <th scope="col" className="px-6 py-3">Customer</th>
                <th scope="col" className="px-6 py-3">Issue Date</th>
                <th scope="col" className="px-6 py-3">Amount</th>
                <th scope="col" className="px-6 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredInvoices.map((invoice) => (
                <tr key={invoice.id} className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                  <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">{invoice.invoiceNumber}</td>
                  <td className="px-6 py-4">{invoice.customerName}</td>
                  <td className="px-6 py-4">{formatDate(invoice.issueDate)}</td>
                  <td className="px-6 py-4">{formatCurrency(calculateInvoiceGrandTotal(invoice), businessInfo.currency)}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${ invoice.status === 'PAID' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'}`}>
                      {invoice.status}
                    </span>
                  </td>
                </tr>
              ))}
                {filteredInvoices.length === 0 && (
                    <tr className="bg-white dark:bg-gray-800 border-b dark:border-gray-700">
                        <td colSpan={5} className="text-center py-8 text-gray-500 dark:text-gray-400">
                            No invoices match the current filters.
                        </td>
                    </tr>
                )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const DownloadIcon = (props: React.SVGProps<SVGSVGElement>) => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" {...props}><path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" /></svg>;

export default Reports;
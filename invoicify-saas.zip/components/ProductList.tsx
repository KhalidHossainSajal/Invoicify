
import React, { useState } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { type Product, type BusinessInfo } from '../types';
import { formatCurrency, generateId } from '../lib/utils';

const ProductList: React.FC = () => {
  const [products, setProducts] = useLocalStorage<Product[]>('products', []);
  // FIX: Provide a complete default object for BusinessInfo to satisfy the type.
  const [businessInfo] = useLocalStorage<BusinessInfo>('businessInfo', {
    name: '',
    address: '',
    email: '',
    phone: '',
    logoUrl: '',
    currency: 'USD',
    invoicePrefix: 'INV-'
  });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<Partial<Product>>({});

  const openModal = (product?: Product) => {
    setCurrentProduct(product || { id: generateId(), name: '', description: '', price: 0 });
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentProduct({});
  };

  const handleSave = () => {
    if (products.find(p => p.id === currentProduct.id)) {
      setProducts(products.map(p => p.id === currentProduct.id ? (currentProduct as Product) : p));
    } else {
      setProducts([...products, currentProduct as Product]);
    }
    closeModal();
  };
  
  const handleDelete = (id: string) => {
      if(window.confirm('Are you sure you want to delete this product?')) {
          setProducts(products.filter(p => p.id !== id));
      }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCurrentProduct({ ...currentProduct, [name]: name === 'price' ? parseFloat(value) : value });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Products</h1>
        <button onClick={() => openModal()} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-blue-600 transition-colors flex items-center">
          <PlusIcon className="h-5 w-5 mr-2" />
          Add Product
        </button>
      </div>

      <div className="bg-card dark:bg-gray-800 shadow-sm rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-300">
              <tr>
                <th scope="col" className="px-6 py-3">Product Name</th>
                <th scope="col" className="px-6 py-3">Description</th>
                <th scope="col" className="px-6 py-3">Price</th>
                <th scope="col" className="px-6 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => (
                <tr key={product.id} className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                  <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">{product.name}</td>
                  <td className="px-6 py-4">{product.description}</td>
                  <td className="px-6 py-4">{formatCurrency(product.price, businessInfo.currency)}</td>
                  <td className="px-6 py-4 flex items-center space-x-2">
                    <button onClick={() => openModal(product)} className="text-primary hover:text-blue-800"><PencilIcon/></button>
                    <button onClick={() => handleDelete(product.id)} className="text-red-500 hover:text-red-700"><TrashIcon/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-8 w-full max-w-md">
            <h2 className="text-2xl font-bold mb-6">{currentProduct.name ? 'Edit Product' : 'Add Product'}</h2>
            <div className="space-y-4">
              <input
                type="text"
                name="name"
                value={currentProduct.name || ''}
                onChange={handleChange}
                placeholder="Product Name"
                className="w-full px-3 py-2 border border-border dark:border-gray-600 text-text-primary bg-white dark:bg-gray-700 dark:text-white rounded-lg"
              />
              <textarea
                name="description"
                value={currentProduct.description || ''}
                onChange={handleChange}
                placeholder="Description"
                className="w-full px-3 py-2 border border-border dark:border-gray-600 text-text-primary bg-white dark:bg-gray-700 dark:text-white rounded-lg"
                rows={3}
              />
              <input
                type="number"
                name="price"
                value={currentProduct.price || ''}
                onChange={handleChange}
                placeholder="Price"
                className="w-full px-3 py-2 border border-border dark:border-gray-600 text-text-primary bg-white dark:bg-gray-700 dark:text-white rounded-lg"
              />
            </div>
            <div className="flex justify-end space-x-4 mt-8">
              <button onClick={closeModal} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 text-text-secondary dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-500">Cancel</button>
              <button onClick={handleSave} className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-blue-600">Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Icons
// FIX: Update PlusIcon to accept props, allowing className to be passed.
const PlusIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
    </svg>
);
const PencilIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" /></svg>;
const TrashIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" /></svg>;

export default ProductList;
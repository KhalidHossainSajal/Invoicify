
import React, { useState, useEffect } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { type Invoice, type BusinessInfo } from '../types';
import { formatCurrency } from '../lib/utils';
import { generateSalesSummary } from '../services/geminiService';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface DashboardProps {
  onNewInvoice: () => void;
  invoices: Invoice[];
}

const StatCard: React.FC<{ title: string; value: string; icon: React.ReactElement }> = ({ title, value, icon }) => (
  <div className="bg-card dark:bg-gray-800 p-6 rounded-lg shadow-sm flex items-center">
    <div className="bg-primary/10 text-primary p-3 rounded-full">{icon}</div>
    <div className="ml-4">
      <p className="text-sm text-text-secondary dark:text-gray-400 font-medium">{title}</p>
      <p className="text-2xl font-bold text-text-primary dark:text-gray-100">{value}</p>
    </div>
  </div>
);

const Dashboard: React.FC<DashboardProps> = ({ onNewInvoice, invoices }) => {
  // FIX: Provide a complete default object for BusinessInfo to satisfy the type.
  const [businessInfo] = useLocalStorage<BusinessInfo>('businessInfo', {
    name: '',
    address: '',
    email: '',
    phone: '',
    logoUrl: '',
    currency: 'USD',
    invoicePrefix: 'INV-'
  });
  const [summary, setSummary] = useState('');
  const [isLoadingSummary, setIsLoadingSummary] = useState(false);

  const totalRevenue = invoices
    .filter(inv => inv.status === 'PAID')
    .reduce((acc, inv) => acc + inv.items.reduce((sum, item) => sum + item.price * item.quantity, 0), 0);
  
  const outstandingRevenue = invoices
    .filter(inv => inv.status === 'DUE')
    .reduce((acc, inv) => acc + inv.items.reduce((sum, item) => sum + item.price * item.quantity, 0), 0);
  
  const paidInvoicesCount = invoices.filter(inv => inv.status === 'PAID').length;

  const chartData = invoices.map(inv => ({
      name: inv.invoiceNumber,
      amount: inv.items.reduce((sum, item) => sum + item.price * item.quantity, 0),
      status: inv.status,
  })).slice(-10); // Last 10 invoices

  const handleGenerateSummary = () => {
    setIsLoadingSummary(true);
    // get invoices from the last 7 days
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const recentInvoices = invoices.filter(inv => new Date(inv.issueDate) >= oneWeekAgo && inv.status === 'PAID');
    
    generateSalesSummary(recentInvoices)
      .then(setSummary)
      .finally(() => setIsLoadingSummary(false));
  };
  
  useEffect(() => {
      handleGenerateSummary();
      // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [invoices]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <button onClick={onNewInvoice} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-blue-600 transition-colors flex items-center">
          <PlusIcon className="h-5 w-5 mr-2" />
          New Invoice
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard title="Total Revenue" value={formatCurrency(totalRevenue, businessInfo.currency)} icon={<DollarIcon />} />
        <StatCard title="Outstanding" value={formatCurrency(outstandingRevenue, businessInfo.currency)} icon={<ClockIcon />} />
        <StatCard title="Paid Invoices" value={String(paidInvoicesCount)} icon={<CheckCircleIcon />} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-card dark:bg-gray-800 p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold mb-4">Recent Invoice Activity</h2>
           <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <XAxis dataKey="name" tick={{ fill: 'currentColor', fontSize: 12 }} />
              <YAxis tickFormatter={(tick) => formatCurrency(tick as number, businessInfo.currency)} tick={{ fill: 'currentColor', fontSize: 12 }}/>
              <Tooltip 
                formatter={(value) => formatCurrency(value as number, businessInfo.currency)}
                contentStyle={{ backgroundColor: 'rgba(31, 41, 55, 0.8)', border: 'none' }}
                labelStyle={{ color: '#f3f4f6' }}
              />
              <Legend wrapperStyle={{ color: 'currentColor' }}/>
              <Bar dataKey="amount" fill="#3B82F6" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card dark:bg-gray-800 p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold mb-4">AI Weekly Summary</h2>
          {isLoadingSummary ? (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <p className="text-text-secondary dark:text-gray-400 text-sm leading-relaxed">{summary}</p>
          )}
          <button onClick={handleGenerateSummary} disabled={isLoadingSummary} className="mt-4 w-full bg-secondary text-white py-2 px-4 rounded-lg text-sm font-semibold hover:bg-green-600 transition-colors disabled:bg-gray-400">
            {isLoadingSummary ? 'Generating...' : 'Regenerate Summary'}
          </button>
        </div>
      </div>
    </div>
  );
};

// SVG Icons
const DollarIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v.01" />
  </svg>
);
const ClockIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);
const CheckCircleIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);
// FIX: Update PlusIcon to accept props, allowing className to be passed.
const PlusIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
    </svg>
);

export default Dashboard;
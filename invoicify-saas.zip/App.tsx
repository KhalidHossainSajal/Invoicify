
import React, { useState } from 'react';
import LandingPage from './components/LandingPage';
import LoginPage from './components/LoginPage';
import RegisterPage from './components/RegisterPage';
import MainLayout from './components/MainLayout';
import { useAuth } from './hooks/useAuth';
import { useTheme } from './hooks/useTheme';

const App: React.FC = () => {
  const { isAuthenticated, login, logout } = useAuth();
  const [view, setView] = useState<'landing' | 'login' | 'register'>('landing');
  const [theme, toggleTheme] = useTheme();

  const register = () => {
    // In a real app, this would involve creating a new user.
    // For this simulation, we'll log them in immediately.
    login();
  };

  // If the user is authenticated, show the main application.
  if (isAuthenticated) {
    return <MainLayout onLogout={logout} theme={theme} toggleTheme={toggleTheme} />;
  }
  
  // Show registration page
  if (view === 'register') {
    return <RegisterPage onRegister={register} onNavigateToLogin={() => setView('login')} onNavigateToLanding={() => setView('landing')} />;
  }

  // If the user is not authenticated, show the login page.
  if (view === 'login') {
    return <LoginPage onLogin={login} onNavigateToLanding={() => setView('landing')} onNavigateToRegister={() => setView('register')} />;
  }
  
  // By default, show the public landing page.
  return <LandingPage onNavigateToLogin={() => setView('login')} onNavigateToRegister={() => setView('register')} />;
};

export default App;
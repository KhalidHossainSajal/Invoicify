import { type Invoice } from '../types';

export const formatCurrency = (amount: number, currency = 'USD') => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency,
  }).format(amount);
};

export const formatDate = (dateString: string) => {
    try {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        });
    } catch (e) {
        return "Invalid Date";
    }
};

export const generateId = () => {
    return Math.random().toString(36).substr(2, 9);
}

export const calculateInvoiceGrandTotal = (invoice: Invoice) => {
    const subtotal = invoice.items.reduce((acc, item) => acc + item.quantity * item.price, 0);
    const discountAmount = Number(invoice.discount) || 0;
    const subtotalAfterDiscount = subtotal - discountAmount;
    const taxAmount = subtotalAfterDiscount * ((Number(invoice.tax) || 0) / 100);
    const grandTotal = subtotalAfterDiscount + taxAmount;
    return grandTotal;
};